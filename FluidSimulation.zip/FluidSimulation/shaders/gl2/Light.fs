uniform vec3 lcolor;

void main()
{
	gl_FragColor = vec4(lcolor, 1.0);
}

