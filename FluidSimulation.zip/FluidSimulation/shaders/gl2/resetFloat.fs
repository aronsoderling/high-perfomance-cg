void main()
{
	gl_FragData[0] = vec4(0.5, 0.0, 0.0, 1.0);
}
