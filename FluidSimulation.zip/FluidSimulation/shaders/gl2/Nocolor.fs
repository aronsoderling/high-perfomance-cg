varying vec4 gl_FragCoord;
void main()
{
	
	gl_FragData[0] = vec4(0.0,0.0, 0.0, 1.0);
}
