/*
 */

#ifndef RC_RAY_H
#define RC_RAY_H

class Ray {

	public:

		vec3f		origin;
		vec3f		direction;

};

#endif /* RC_RAY_H */

