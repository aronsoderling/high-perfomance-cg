
/* Inclusion guard */
#ifndef PROGRAM_H
#define PROGRAM_H

/*
	Uncomment to pick (one) active program
*/

//#define OGRE				/* demo */
//#define SPONZA				/* demo */
//#define ASSIGNMENT_1		/* solar system */
//#define ASSIGNMENT_23		/* interpolation, tessellation, shaders */
#define EDAN35				/* Assignment 2 */

#endif /* PROGRAM_H */
